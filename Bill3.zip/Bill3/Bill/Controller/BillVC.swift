//
//  BillVC.swift
//  Bill
//
//  Created by C on 2022/5/8.
//

import UIKit

class BillVC: UIViewController {
    var accountModel = AccountModel()
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var accountLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // refresh data
        accountModel = DataManager.share.getAccountModelWithAccount(account: accountModel.account)
        tableView.reloadData()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Bill"
        self.nameLabel.text = "Name:\(accountModel.name)"
        self.accountLabel.text = "Account:\(accountModel.account)"
        tableView.dataSource = self
        tableView.delegate = self
        tableView.tableFooterView = UIView()
        // Do any additional setup after loading the view.
    }
    //
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if  segue.identifier == "toAddBillVCPage",
           let vc = segue.destination as? AddBillVC{
            vc.accountModel = accountModel
            return
        }
        if  segue.identifier == "toBillAnalysisVCPage",
           let vc = segue.destination as? BillAnalysisVC{
            vc.accountModel = accountModel
            return
        }
        
    }

}
extension BillVC:UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return accountModel.billList.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "billCellID", for: indexPath) as! BillCell
        let billModel = accountModel.billList[indexPath.row]
        cell.typeAmountLabel.text = "\(billModel.billType):" + String(format: "%.2lf$", billModel.amount)
        cell.singLabel.text = billModel.sign
        
        // time stamp conver date string
        let date = Date(timeIntervalSince1970: TimeInterval(billModel.date))
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let dateString = dateFormatter.string(from: date)
        cell.dateLabel.text = "date:\(dateString)"
        cell.remarkLabel.text = "remarks:\(billModel.remarks=="" ? "no":billModel.remarks)"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
       
        let deleteAction = UIContextualAction(style: .normal, title: "Delete", handler: { (action, view, completionHandler) in
            let billModel = self.accountModel.billList[indexPath.row]
            //delete
            DataManager.share.deleteBillModel(account: billModel.account, billID: billModel.id)
            //update data source
            self.accountModel = DataManager.share.getAccountModelWithAccount(account: self.accountModel.account)
            self.tableView.reloadData()
        })
        deleteAction.backgroundColor = .red
        return UISwipeActionsConfiguration(actions: [ deleteAction])
    }
    
}
