//
//  ChoiceTimeVC.swift
//  Bill
//
//  Created by C on 2022/5/10.
//

import UIKit

class ChoiceTimeVC: UIViewController {
    var finishHandler:((_ isMonth:Bool,_ start:TimeInterval,_ end:TimeInterval)->())?
    @IBOutlet weak var choiceLabel: UILabel!
    @IBOutlet weak var dayContainV: UIView!
    @IBOutlet weak var startTF: UITextField!
    
    @IBOutlet weak var endTF: UITextField!
    
    @IBOutlet weak var monthTF: UITextField!
    
    var isMonth = true
    var start: TimeInterval = 0
    var end: TimeInterval = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        //defaulr
        choiceLabel.text = "Select Month"
        //defaulr
        isMonth = true
        
        monthTF.delegate = self
        startTF.delegate = self
        endTF.delegate = self
        
        
        dayContainV.isHidden = true
        monthTF.isHidden = false
        
    }
    

    @IBAction func sureAction(_ sender: Any) {
        if start == 0 || end == 0 || start > end {
            showAlertVC(message: "time error",handler: nil)
            return
        }
        finishHandler?(isMonth,start,end)
        self.navigationController?.popViewController(animated: false)
    }
    //choice Month and day
    @IBAction func choiceAction(_ sender: Any) {
        if isMonth {
            choiceLabel.text = "Day"
            dayContainV.isHidden = false
            monthTF.isHidden = true
            isMonth = false
        }else{
            choiceLabel.text = "Month"
            dayContainV.isHidden = true
            monthTF.isHidden = false
            isMonth = true
        }
        startTF.text = ""
        endTF.text = ""
        monthTF.text = ""
    }
    
    
    func chooseDateAction(tf:UITextField)  {
        let datePick = AYPopupDatePickerView()
        datePick.display(defaultDate: Date()) { date in
            
            let dateFormatter = DateFormatter()
            dateFormatter.locale = Locale(identifier: "en_US_POSIX")
            if self.isMonth {
                dateFormatter.dateFormat = "yyyy-MM"
                self.start = startOfCurrentMonth(date).timeIntervalSince1970
                self.end = endOfCurrentMonth(date).timeIntervalSince1970
            }else{
                dateFormatter.dateFormat = "yyyy-MM-dd"
                if tf == self.startTF{
                    //get one day start
                    let daySec = (NSInteger(date.timeIntervalSince1970) + 3600*8)%(3600*24)
                    let dayStartSec = NSInteger(date.timeIntervalSince1970) - daySec
                    self.start = Double(dayStartSec)
                }else{
                    //get one day end
                    let daySec = (NSInteger(date.timeIntervalSince1970) + 3600*8)%(3600*24)
                    let dayEndSec = NSInteger(date.timeIntervalSince1970) + (3600*24 - daySec)
                    self.end = Double(dayEndSec - 1)
                }
            }
            
            let dateString = dateFormatter.string(from: date)
            
            tf.text = dateString
        
            
        }
        
    }

}

extension ChoiceTimeVC:UITextFieldDelegate{
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        view.endEditing(true)
        self.chooseDateAction(tf: textField)
        return false
    }
}
