//
//  AddBillVC.swift
//  Bill
//
//  Created by C on 2022/5/8.
//

import UIKit

class AddBillVC: UIViewController {
    var accountModel = AccountModel()
    
    
    @IBOutlet weak var accountTF: UITextField!
    @IBOutlet weak var billTypeTF: UITextField!
    @IBOutlet weak var amountTF: UITextField!
    @IBOutlet weak var signTF: UITextField!
    @IBOutlet weak var dateTF: UITextField!
    @IBOutlet weak var remarksTF: UITextField!
    
    var textFieldList = [UITextField]()
    var billTypeDict:[String:[String]] = ["Transfer":["Other"],
                                          "Outcome":["Food","Accommodation","Shopping","Extra Fee","Other"],
                                          "Income":["Salary","Part-time","Bonus","Other"]]
    
    var date:Date?
    var billType:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        textFieldList = [accountTF,billTypeTF,amountTF,signTF,dateTF,remarksTF]
        for (_,textField) in textFieldList.enumerated() {
            textField.delegate =  self
        }
        self.accountTF.text = accountModel.name + "/" + accountModel.account
        // Do any additional setup after loading the view.
    }
    
    @IBAction func saveBillAction(_ sender: Any) {
        //2
        guard let billType = billTypeTF.text,
              billType.count > 0 else {
                  showAlertVC(message: "Bill Type is error",handler: nil)
                  return
              }
        //3
        guard let amount = amountTF.text,
              amount.count > 0,
              let amou = Double(amount),
              amou >= 0
             else {
                  showAlertVC(message: "Amount is error",handler: nil)
                  return
              }
        //4
        var sign = "Other"
        if  let signTemp = signTF.text {
            sign = signTemp
        }
        //5
        guard let date = date else {
            showAlertVC(message: "Date is error",handler: nil)
            return
        }
        //6
        var remarks = ""
        if let remarksTemp = remarksTF.text,
           billType.count > 0 {
            remarks = remarksTemp
        }
        // creat BillModel
        let billModel = BillModel(account: accountModel.account, billType: billType,amount: amou , sign: sign, date: NSInteger(date.timeIntervalSince1970), remarks: remarks)
        DataManager.share.addBillModel(billModel: billModel, complete: { success, msg in
            showAlertVC(message: msg,handler: nil)
        })
    }
    
    //1 Account
    func chooseAccountAction(tf:UITextField)  {
        var accountArray = [String]()
        for (_,item) in DataManager.share.accountModelList.enumerated() {
            accountArray.append(item.name +  "/" + item.account)
        }
        let pickerView = AYPopupPickerView()
        pickerView.display(itemTitles: accountArray, defaultIndex: 1) {
            let selectedIndex = pickerView.pickerView.selectedRow(inComponent: 0)
            self.accountTF.text = accountArray[selectedIndex]
            self.accountModel = DataManager.share.accountModelList[selectedIndex]
        }
    }
    //2Bill type
    func chooseBillAction(tf:UITextField)  {
        let pickerView = AYPopupPickerView()
        var list = [String]()
        list = Array(billTypeDict.keys)
        pickerView.display(itemTitles:list, defaultIndex: 1) {
            let selectedIndex = pickerView.pickerView.selectedRow(inComponent: 0)
            self.billTypeTF.text = list[selectedIndex]
            self.billType = list[selectedIndex]
            self.signTF.text = ""
        }
    }
    //4Sign
    func chooseSignAction(tf:UITextField)  {
        if let billType = billType,
           let list = billTypeDict[billType]  {
            
            let pickerView = AYPopupPickerView()
            pickerView.display(itemTitles:list, defaultIndex: 1) {
                let selectedIndex = pickerView.pickerView.selectedRow(inComponent: 0)
                self.signTF.text = list[selectedIndex]
                
            }
        }else{
            showAlertVC(message: "Please first choice BillType",handler: nil)
        }
        
    }
    //5Date
    func chooseDateAction(tf:UITextField)  {
        let datePick = AYPopupDatePickerView()
        datePick.datePickerView.datePickerMode = .dateAndTime
        datePick.display(defaultDate: Date()) { date in
            
            let dateFormatter = DateFormatter()
            dateFormatter.locale = Locale(identifier: "en_US_POSIX")
            dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
            let dateString = dateFormatter.string(from: date)
            self.dateTF.text = dateString
            self.date = date
        }
        
    }
    
}

extension AddBillVC:UITextFieldDelegate{
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        view.endEditing(true)
        if accountTF == textField {
            self.chooseAccountAction(tf: textField)
            return false
        }else  if billTypeTF == textField {
            self.chooseBillAction(tf: textField)
            return false
        }else  if signTF == textField {
            self.chooseSignAction(tf: textField)
            return false
        }else  if dateTF == textField {
            self.chooseDateAction(tf: textField)
            return false
        }
        
        return true
    }
    
}
