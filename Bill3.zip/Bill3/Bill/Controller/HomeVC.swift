//
//  HomeVC.swift
//  Bill
//
//  Created by C on 2022/5/8.
//

import UIKit

class HomeVC: UIViewController {
    var accountType = 1
    @IBOutlet weak var tableView: UITableView!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        //accountID
        tableView.dataSource = self
        tableView.delegate = self
        tableView.tableFooterView = UIView()
    }
    
    @IBAction func addAccountAction(_ sender: Any) {
        let alertVC = UIAlertController(title: "", message: "Add Account", preferredStyle: .actionSheet)
        //Account type
        let action1 =  UIAlertAction(title: "Saving Account", style: .default){
            _ in
            self.accountType = 1
            self.performSegue(withIdentifier: "addAccountSegueID", sender: nil)
        }
        let action2 =  UIAlertAction(title: "Credit Account", style: .default){
            _ in
            self.accountType  = 2
            self.performSegue(withIdentifier: "addAccountSegueID", sender: nil)
        }
        let action3 =  UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alertVC.addAction(action1)
        alertVC.addAction(action2)
        alertVC.addAction(action3)
        self.present(alertVC, animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if  segue.identifier == "addAccountSegueID",
           let vc = segue.destination as? AddAccountVC{
            //Transfer data
            vc.accountType = self.accountType
            return
        }
        if  segue.identifier == "toBillVCPage",
           let vc = segue.destination as? BillVC,
            let indexPath = tableView.indexPathForSelectedRow {
            //Transfer data
            vc.accountModel = DataManager.share.accountModelList[indexPath.row]
            return
        }
            
            
    }

}

extension HomeVC:UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return DataManager.share.accountModelList.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "accountID", for: indexPath) as! AccountCell
        let accountModel = DataManager.share.accountModelList[indexPath.row]
        cell.nameLabel.text = "Name:" + accountModel.name
        cell.numberLabel.text = "Card Number:" + accountModel.account
      
        if accountModel.type == 1 {
            cell.typeLabel.text = "Saving Account"
            cell.balanceLabel.text = "Balance:" + String(format: "%.2lf", accountModel.balance) + "$"
        }else{
            cell.typeLabel.text = "Credit Account"
            cell.balanceLabel.text = "Balance:" + String(format: "%.2lf", accountModel.balance) + "$" + "   Available:" + String(format: "%.2lf", accountModel.available) + "$"
        }
        return cell
    }
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let deleteAction = UIContextualAction(style: .normal, title: "Delete", handler: { (action, view, completionHandler) in
            let accountModel = DataManager.share.accountModelList[indexPath.row]
            DataManager.share.deleteAccountModel(accountModel: accountModel)
            self.tableView.reloadData()
        })
        deleteAction.backgroundColor = .red
        return UISwipeActionsConfiguration(actions: [ deleteAction])
    }
   
}
