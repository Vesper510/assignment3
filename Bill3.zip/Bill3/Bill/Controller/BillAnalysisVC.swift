//
//  BillAnalysisVC.swift
//  Bill
//
//  Created by C on 2022/5/8.
//

import UIKit

class BillAnalysisVC: UIViewController {
    var accountModel = AccountModel()
    let viewW = UIScreen.main.bounds.width
    
    //@IBOutlet weak var choiceView: UIView!
    
    @IBOutlet weak var choiceLabel: UILabel!
    
    @IBOutlet weak var incomeLabel: UILabel!
    
    @IBOutlet weak var outComeLabel: UILabel!
    
    @IBOutlet weak var transferLabel: UILabel!
    
    var isMonth = true
    var start:TimeInterval = 0
    var end:TimeInterval = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        let currentDate = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        dateFormatter.dateFormat = "yyyy-MM"
        choiceLabel.text = dateFormatter.string(from:currentDate)
        let  startDate = startOfCurrentMonth(currentDate)
        let  endDate = endOfCurrentMonth(currentDate)
        self.start = startDate.timeIntervalSince1970
        self.end = endDate.timeIntervalSince1970
        self.setdata()
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if  segue.identifier == "toChoiceTimeVCPage",
           let vc = segue.destination as? ChoiceTimeVC{
            //Data callback
            vc.finishHandler = {
               [weak self] isMonth,start,end in
                self?.isMonth = isMonth
                self?.start = start
                self?.end = end
                
               // date string
                let dateFormatter = DateFormatter()
                dateFormatter.locale = Locale(identifier: "en_US_POSIX")
                if isMonth {
                    dateFormatter.dateFormat = "yyyy-MM"
                    self?.choiceLabel.text = dateFormatter.string(from:Date(timeIntervalSince1970: start))
                }else{
                    dateFormatter.dateFormat = "yyyy-MM-dd"
                    self?.choiceLabel.text = dateFormatter.string(from:Date(timeIntervalSince1970: start))  + " to " + dateFormatter.string(from:Date(timeIntervalSince1970: end))
                    
                }
                self?.setdata()
            }
            return
        }
    }
    
    
    
    func setdata() {
        print(start)
        print(end)
        // filter list
        let billModelList = DataManager.share.getAnalysisData(start: NSInteger(start), end: NSInteger(end))
        let incomeList = billModelList.filter({$0.billType=="Income"})
        let outcomeList = billModelList.filter({$0.billType=="Outcome"})
        let  transferList = billModelList.filter({$0.billType=="Transfer"})
        
        // conver to double and
        let incomeSalary = incomeList.filter({$0.sign=="Salary"}).map({$0.amount}).reduce(0, +)
        let incomePart_time = incomeList.filter({$0.sign=="Part-time"}).map({$0.amount}).reduce(0, +)
        let incomeBonus = incomeList.filter({$0.sign=="Bonus"}).map({$0.amount}).reduce(0, +)
        let incomeOther = incomeList.filter({$0.sign=="Other"}).map({$0.amount}).reduce(0, +)
        
        
        let outcomeFood = outcomeList.filter({$0.sign=="Food"}).map({$0.amount}).reduce(0, +)
        let outcomeAccommodation = outcomeList.filter({$0.sign=="Accommodation"}).map({$0.amount}).reduce(0, +)
        let outcomeShopping = outcomeList.filter({$0.sign=="Shopping"}).map({$0.amount}).reduce(0, +)
        let outcomeExtra_Fee = outcomeList.filter({$0.sign=="Extra Fee"}).map({$0.amount}).reduce(0, +)
        let outcomeOther = outcomeList.filter({$0.sign=="Other"}).map({$0.amount}).reduce(0, +)
     
        let transferOther = transferList.map({$0.amount}).reduce(0, +)
        
        
        //1incomeLabel
        self.incomeLabel.text = "Salary:" + String(format: "%.2lf", incomeSalary) + "\nPart-time:" + String(format: "%.2lf", incomePart_time) + "\nBonus:" + String(format: "%.2lf", incomeBonus) + "\nOther:" + String(format: "%.2lf", incomeOther)
        
        //2outComeLabel
        self.outComeLabel.text = "Food:" + String(format: "%.2lf", outcomeFood) + "\nAccommodation:" + String(format: "%.2lf", outcomeAccommodation) + "\nShopping:" + String(format: "%.2lf", outcomeShopping) + "\nExtra Fee:" + String(format: "%.2lf", outcomeExtra_Fee) + "\nOther:" + String(format: "%.2lf", outcomeOther)
        
        //3transferLabel
        self.transferLabel.text = "Transfer:" + String(format: "%.2lf", transferOther)
    }
    

}
