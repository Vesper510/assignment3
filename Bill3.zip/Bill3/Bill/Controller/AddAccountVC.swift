//
//  AddAccountVC.swift
//  Bill
//
//  Created by C on 2022/5/8.
//

import UIKit

class AddAccountVC: UIViewController {
    var accountType = 1
    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var numberTextField: UITextField!
    @IBOutlet weak var balanceTextField: UITextField!
    @IBOutlet weak var availableTextField: UITextField!
    
    @IBOutlet weak var availableLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        if self.accountType == 1 {
            availableTextField.isHidden = true
            availableLabel.isHidden = true
        }
    }
    
    @IBAction func addAccountAction(_ sender: Any) {
        guard let name = nameTextField.text,
        name.count > 0 else {
            showAlertVC(message: "Name is empty",handler: nil)
            return
        }
        // card number must number and >0
        guard let number = numberTextField.text?.replacingOccurrences(of: " ", with: ""),
              number.count > 0,
              let num = Int(number),
              num > 0 else {
                  showAlertVC(message: "number is error",handler: nil)
                  return
              }
        // balance  must number  and >0
        guard let balance = balanceTextField.text,
              balance.count > 0,
              let balan = Double(balance)
             else {
                  showAlertVC(message: "Balance is error",handler: nil)
                  return
              }
        
     
        
        if accountType == 1 {
            // creat Saving Account model
            let accountModel =   AccountModel(name: name, account:number , balance: balan, available: 0, billList: [BillModel](), type:accountType)
            DataManager.share.addAccountModel(accountModel: accountModel, complete: { success, msg in
                showAlertVC(message: msg,handler: nil)
            })
            
        }else{
            guard let available = availableTextField.text,
                  available.count > 0,
                  let avail = Double(available) else
                  {
                      showAlertVC(message: "Credit Account",handler: nil)
                      return
                  }
            // // creat Saving Account model
           let accountModel =   AccountModel(name: name, account:number , balance: balan, available: round(avail), billList: [BillModel](), type:accountType)
            DataManager.share.addAccountModel(accountModel: accountModel, complete: { success, msg in
                showAlertVC(message: msg,handler: nil)
            })
            
        }
        
    }
    
}
