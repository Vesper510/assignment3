//
//  BillCell.swift
//  Bill
//
//  Created by C on 2022/5/8.
//

import UIKit

class BillCell: UITableViewCell {

    @IBOutlet weak var typeAmountLabel: UILabel!
    
    @IBOutlet weak var singLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    
    @IBOutlet weak var remarkLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
