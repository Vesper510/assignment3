//
//  Models.swift
//  Bill
//
//  Created by C on 2022/5/8.
//

import Foundation


struct AccountModel:Codable {
    var name: String = ""
    var account: String = ""
    var balance: Double = 0
    var available:Double = 0
    var billList = [BillModel]()
    var type = 1 // 1Saving Account   2Credit Account
}



struct BillModel:Codable {
    var id = UUID().uuidString
    var account: String = ""
    var billType:String = ""
    var amount:Double = 0
    var sign:String = ""
    var date:NSInteger = 0
    var remarks:String = ""
    
}




//账单类型
enum BillType {
    
    case income(value:String  = "Income",incomeType:BillIncomeType)
    case outcome(value:String  = "Outcome",outcomeType:BillOutcomeType)
    case transfer(value:String  = "Transfer")
}

enum BillIncomeType : String {
    
    case salary = "Salary"
    case part_time = "Part-time"
    case bonus = "Bonus"
    case other = "Other"
}

enum BillOutcomeType : String {
    
    case food = "Food"
    case accommodation = "Accommodation"
    case shopping = "Shopping"
    case extra_fee = "Extra Fee"
    case other = "Other"
}

/*
 第一页
 账户详情页面
 可以添加存款账户Saving Account（ Account name，Balance）
 可以添加信用卡账户Credit Account（Account name，Available，Balance）
 点击不同账户可以查看该账户账单

 第二页
 账单页
 可以添加账单
 账单为三种，Income，Outcome，Transfer
 收入Income可标记类型：Salary，Part-time，Bonus
 支出Outcome可标记类型：Food，Accommodation, Shopping, Extra Fee

 记录账单时选择支出或收入的账户，类型，日期，备注（备注可以为空）

 可以根据支出类型生成饼图查看收入或支出占比。

 需要验证错误输入，保证输入正确。例如信用卡可以透支账户，存款账户不可以。
 功能：
 */
