//
//  DataManager.swift
//  Bill
//
//  Created by C on 2022/5/9.
//

import Foundation
    

class DataManager {
    var accountModelList = [AccountModel]()
    static let  share = DataManager()
    init(){
        if let data  = try? Data(contentsOf: Self.fileURL),
           let model = try? JSONDecoder().decode([AccountModel].self, from: data) ,
           model.count > 0{
            accountModelList = model
        }else{
        }
        
    }
    
    //getAccountModel data
    func getAccountModelWithAccount(account:String) -> AccountModel {
        for (_,item) in accountModelList.enumerated() where item.account == account  {
            
            return item
        }
        var new = AccountModel()
        new.account = account
        return new
    }
    
    // add Account
    func addAccountModel(accountModel:AccountModel, complete:(_ success:Bool,_ msg:String)->()) {
        for (_,item) in accountModelList.enumerated() where item.account == accountModel.account  {
            complete(false,"Account already exists")
            return
        }
        accountModelList.append(accountModel)
        complete(true,"Add success")
        self.save()
    }
    
    // add BillModel
    func addBillModel(billModel:BillModel, complete:(_ success:Bool,_ msg:String)->())  {
        var index = -1
        for (indexTemp,item) in accountModelList.enumerated() where item.account == billModel.account  {
            index = indexTemp
            break
        }
        if index >= 0 {
            // AccountModel value type
            // Calculate balance
            var accountModel = accountModelList[index]
            if billModel.billType == "Income" {
                accountModel.balance += billModel.amount
            }else if billModel.billType == "Outcome" {
                accountModel.balance -= billModel.amount
            }else if billModel.billType == "Transfer" {
                accountModel.balance -= billModel.amount
            }else{
                complete(false,"Invalid billing type")
                return
            }
            //Saving Account
            if accountModel.type == 1 && accountModel.balance < 0 {
                complete(false,"balance is not enough")
                return
            }
            //Credit Account
            if accountModel.type == 2 && accountModel.balance < (-accountModel.available) {
                complete(false,"Sorry, your available is not enough")
                return
            }
            accountModelList[index].balance = accountModel.balance
            accountModelList[index].billList.insert(billModel, at: 0)
            complete(true,"Save success")
            self.save()
        }else{
            complete(false,"Invalid account")
        }
    }
    
    func getAnalysisData(start:NSInteger,end:NSInteger) -> [BillModel] {
        var resultList = [BillModel]()
        for (_,item) in accountModelList.enumerated()  {
            
            let filter = item.billList.filter { model in
                return  model.date >= start &&  model.date <= end
            }
            resultList.append(contentsOf: filter)
            
        }
        return resultList
    }
    
    func deleteAccountModel(accountModel:AccountModel)  {
        for (index,item) in self.accountModelList.enumerated() where  item.account == accountModel.account{
            self.accountModelList.remove(at: index)
            self.save()
            return
        }
    }
    
    func deleteBillModel(account:String,billID:String)  {
        for (index1,accountModelTemp) in self.accountModelList.enumerated() where  accountModelTemp.account == account{
            
            for (index2,item) in accountModelTemp.billList.enumerated() where  item.id == billID{
                
                self.accountModelList[index1].billList.remove(at: index2)
                self.save()
                return
            }
            return
        }
    }
    
    func save() {
        do {
            let data = try JSONEncoder().encode(self.accountModelList)
            try data.write(to:Self.fileURL, options: .atomic)
         
        } catch {
            print("Could not write file: \(error)")
        }
    }
    
    static var fileURL: URL = {
        let fileName = "bill.json"
        let fm = FileManager.default
        guard let documentDir = fm.urls(for: .documentDirectory, in: .userDomainMask).first else { return URL(fileURLWithPath: "/") }
        let fileURL = documentDir.appendingPathComponent(fileName)
        print(documentDir)
        return fileURL
    }()
}
