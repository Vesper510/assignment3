//
//  Fun.swift
//  Bill
//
//  Created by C on 2022/5/9.
//

import Foundation
import UIKit

//show Alert viewController
func showAlertVC(message:String,handler: (()->())?)  {
    let alertVC = UIAlertController(title: "tips", message: message, preferredStyle: .alert)
    
    let action =  UIAlertAction(title: "Sure", style: .default) {
        _ in
        handler?()
    }
    
    alertVC.addAction(action)
    if let currentWindow = UIViewController.currentWindow() {
        currentWindow.rootViewController?.present(alertVC, animated: true, completion: nil)
    }
}

extension UIViewController{
    class func currentWindow() -> UIWindow?{
        if #available(iOS 13.0, *) {
            guard let connectedScenes = UIApplication.shared.connectedScenes as? Set<UIWindowScene> else {
                return nil
            }
            for windowScene in connectedScenes where windowScene.activationState == UIScene.ActivationState.foregroundActive {
                for windowItem in windowScene.windows where windowItem.rootViewController!.isKind(of: UINavigationController.self){
                    return windowItem
                }
                return windowScene.windows.first
            }
        }else{
            return UIApplication.shared.windows.first
        }
        return nil
    }
}


//本月开始日期
func startOfCurrentMonth(_ date:Date) -> Date {
    let calendar = NSCalendar.current
    let components = calendar.dateComponents(
        Set<Calendar.Component>([.year, .month]), from: date)
    let startOfMonth = calendar.date(from: components)!
    return startOfMonth
}
 
//本月结束日期
func endOfCurrentMonth(_ date:Date) -> Date {
    let calendar = NSCalendar.current
    var components = DateComponents()
    components.month = 1
    components.second = -1
     
    let endOfMonth =  calendar.date(byAdding: components, to: startOfCurrentMonth(date))!
    return endOfMonth
}
